export const loginValues = {
  phone:""
};

export const otpValues = {
  otp: ["", "", "", ""], 
};

export const createNotificationValues = {
  title: "",
  description: "",
  date: "",
  time: "",
  userType: "both",
};
